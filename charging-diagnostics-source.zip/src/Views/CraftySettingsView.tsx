import Download from "lucide-solid/icons/download";
import TriangleAlert from "lucide-solid/icons/triangle-alert";
import { type Component, createSignal, Show } from "solid-js";
import { AnalysisSection } from "../components/AnalysisSection";
import { AppSettingsSection } from "../components/AppSettingsSection";
import { PageTitle } from "../components/DeviceShell";
import { FactoryReset } from "../components/FactoryReset";
import {
  InfoRow,
  SettingRow,
  SettingSlider,
  SettingSwitch,
  SettingsSection,
} from "../components/Settings";
import { Alert, AlertDescription } from "../components/ui/alert";
import {
  createChargingDebugExport,
  downloadChargingDebugExport,
} from "../devices/crafty/chargingDiagnostics";
import { Limits } from "../devices/crafty/protocol";
import { m } from "../paraglide/messages";
import { useBluetooth } from "../provider/BluetoothProvider";
import { useCrafty } from "../provider/CraftyProvider";
import { APP_BUILD_INFO } from "../utils/buildInfo";
import { formatDuration } from "../utils/heatProgress";

export const CraftySettingsView: Component = () => {
  const { state, actions, derived, firmwareVersion, isOldFirmware } =
    useCrafty();
  const { deviceInfo, knownDevice, rememberedDevice } = useBluetooth();
  const [chargingExportStatus, setChargingExportStatus] =
    createSignal<string>();
  const chargingDeviceId = () =>
    deviceInfo().serialNumber || knownDevice()?.id || rememberedDevice()?.id;
  const exportChargingDiagnostics = () => {
    const deviceId = chargingDeviceId();
    if (!deviceId) return;
    try {
      downloadChargingDebugExport(
        createChargingDebugExport(deviceId, APP_BUILD_INFO)
      );
      setChargingExportStatus(m.settings_chargingDebugExported());
    } catch (error) {
      console.error("Could not export charging debug data:", error);
      setChargingExportStatus(m.settings_chargingDebugExportFailed());
    }
  };

  return (
    <>
      <PageTitle>{m.settings_title()}</PageTitle>

      <Show when={isOldFirmware}>
        <Alert variant="accent">
          <TriangleAlert />
          <AlertDescription>{m.crafty_oldDetected()}</AlertDescription>
        </Alert>
      </Show>

      <SettingsSection title={m.settings_sectionDevice()}>
        <SettingSlider
          label={m.settings_deviceBrightness()}
          valueLabel={`${state.ledBrightness} %`}
          value={state.ledBrightness}
          min={Limits.MIN_BRIGHTNESS}
          max={Limits.MAX_BRIGHTNESS}
          step={10}
          onChange={actions.setLedBrightness}
        />
        {/* Auto shutdown - only on Crafty+ */}
        <Show when={!isOldFirmware}>
          <SettingSlider
            label={m.settings_autoShutdownTime()}
            valueLabel={
              state.autoOffCountdown === null
                ? "-"
                : formatDuration(state.autoOffCountdown)
            }
            value={state.autoOffCountdown ?? Limits.MIN_AUTO_OFF}
            min={Limits.MIN_AUTO_OFF}
            max={Limits.MAX_AUTO_OFF}
            step={30}
            onChange={actions.setAutoOffCountdown}
          />
        </Show>
      </SettingsSection>

      <SettingsSection title={m.settings_sectionBehavior()}>
        <SettingSwitch
          label={m.settings_vibration()}
          description={m.settings_enableVibration()}
          checked={derived.isVibrationOn()}
          onChange={actions.setVibration}
        />
        <SettingSwitch
          label={m.settings_chargeIndicatorLamp()}
          description={m.settings_enableChargeLed()}
          checked={derived.isChargeLedOn()}
          onChange={actions.setChargeLed}
        />
        {/* Permanent Bluetooth - not on old firmware */}
        <Show when={!isOldFirmware}>
          <SettingSwitch
            label={m.settings_permanentBluetooth()}
            description={m.settings_keepBluetoothAlwaysOn()}
            checked={derived.isPermanentBluetooth()}
            onChange={actions.setPermanentBluetooth}
          />
        </Show>
      </SettingsSection>

      <AppSettingsSection />

      <Show when={!isOldFirmware}>
        <SettingsSection title={m.settings_sectionCharging()}>
          <SettingRow
            label={m.settings_chargingDebugExport()}
            description={m.settings_chargingDebugExportHint()}
          >
            <button
              type="button"
              class="shrink-0 rounded-lg border px-3 py-2 text-sm disabled:opacity-50"
              disabled={!chargingDeviceId()}
              aria-label={m.settings_chargingDebugExport()}
              onClick={exportChargingDiagnostics}
            >
              <Download class="size-4" />
            </button>
          </SettingRow>
          <Show when={chargingExportStatus()}>
            <p class="px-4 pb-3 text-xs text-muted-foreground" role="status">
              {chargingExportStatus()}
            </p>
          </Show>
          <Show when={!chargingDeviceId()}>
            <p class="px-4 pb-3 text-xs text-muted-foreground">
              {m.settings_chargingDebugNoDevice()}
            </p>
          </Show>
        </SettingsSection>
      </Show>

      <SettingsSection title={m.device_info()}>
        <InfoRow label={m.device_battery()}>{state.batteryLevel} %</InfoRow>
        <InfoRow label={m.crafty_usageTime()}>
          {state.useHours} h{!isOldFirmware && ` ${state.useMinutes ?? 0} min`}
        </InfoRow>
        <Show when={!isOldFirmware}>
          <InfoRow label={m.crafty_autoOffRemaining()}>
            {formatDuration(state.autoOffRemaining ?? 0)}
          </InfoRow>
        </Show>
        <InfoRow label={m.device_firmware()}>{firmwareVersion}</InfoRow>
        <Show when={!isOldFirmware}>
          <InfoRow label={m.crafty_bleFirmware()}>
            {state.bleFirmwareVersion ?? "-"}
          </InfoRow>
        </Show>
        <InfoRow label={m.crafty_statusRegister2()}>
          {state.statusRegister2}
        </InfoRow>
        {/* System status - only on Crafty+ */}
        <Show when={!isOldFirmware}>
          <InfoRow label={m.crafty_systemStatus()}>
            {state.systemStatus ?? "-"}
          </InfoRow>
          <InfoRow label={m.crafty_batteryStatus({ number: 1 })}>
            {state.akkuStatus ?? "-"}
          </InfoRow>
          <InfoRow label={m.crafty_batteryStatus({ number: 2 })}>
            {state.akkuStatus2 ?? "-"}
          </InfoRow>
        </Show>
      </SettingsSection>

      {/* Analysis and factory reset - not on old firmware */}
      <Show when={!isOldFirmware}>
        <SettingsSection title={m.settings_sectionInfo()}>
          <AnalysisSection run={actions.runAnalysis} />
        </SettingsSection>
        <SettingsSection title={m.settings_sectionDanger()}>
          <FactoryReset onReset={actions.factoryReset} />
        </SettingsSection>
      </Show>
    </>
  );
};
